<?php
/* @var $this yii\web\View */
/* @var $form yii\widgets\ActiveForm */
/* @var $generator yii\gii\generators\controller\Generator */

echo $form->field($generator, 'controller');
echo $form->field($generator, 'actions');
echo $form->field($generator, 'ns');
echo $form->field($generator, 'baseClass');
