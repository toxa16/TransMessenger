<?php
/**
 * Application configuration for all backend test types
 */
return [];