# Util Classes

Codeception Util classes are used by various parts of framework and can be used in tests or in other projects. They do not depend on Codeception core, nor they do know of Codeception itself. Thus, some of those classes have static methods.