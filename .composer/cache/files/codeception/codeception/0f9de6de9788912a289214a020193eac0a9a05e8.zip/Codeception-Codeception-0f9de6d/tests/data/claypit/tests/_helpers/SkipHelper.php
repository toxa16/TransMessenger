<?php
namespace Codeception\Module;

// here you can define custom functions for SkipGuy 

class SkipHelper extends \Codeception\Module
{
}
