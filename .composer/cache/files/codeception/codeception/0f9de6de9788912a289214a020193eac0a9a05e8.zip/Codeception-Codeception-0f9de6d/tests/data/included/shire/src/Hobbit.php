<?php
namespace Shire;

class Hobbit
{
    public static function add($a, $b)
    {
        return $a + $b;
    }
}
