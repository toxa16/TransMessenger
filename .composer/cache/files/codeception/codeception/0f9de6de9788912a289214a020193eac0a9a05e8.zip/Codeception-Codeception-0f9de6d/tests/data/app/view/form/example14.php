<html>
<body>
<form action="/form/complex" method="POST" enctype="multipart/form-data">
    <input type="file" name="foo bar" />
    <input type="file" name="foo.baz" />
    <input type="text" name="xxx"/>
    <input type="submit"  name="Submit" />
</form>
</body>
</html>