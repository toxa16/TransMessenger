<html>
<head>
    <meta http-equiv="refresh" content="0; url=http://localhost:8000/info" />
</head>
<body>
    <h1>Redirecting...</h1>
</body>
</html>