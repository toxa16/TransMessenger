<?php
$I = new CodeGuy($scenario);
$I->wantTo('drink beer, actually...');