<?php
$scenario->skip();
$I = new SkipGuy($scenario);
$I->wantTo('skip it');
