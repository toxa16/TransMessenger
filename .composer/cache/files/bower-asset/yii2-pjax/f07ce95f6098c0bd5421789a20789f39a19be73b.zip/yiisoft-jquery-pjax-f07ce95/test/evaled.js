window.evaledSrcScript = true
window.evaledScriptLoaded()
