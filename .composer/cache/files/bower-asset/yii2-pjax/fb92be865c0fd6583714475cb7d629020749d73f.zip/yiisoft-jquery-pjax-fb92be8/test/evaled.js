window.evaledSrcScriptNum = window.evaledSrcScriptNum || 0
window.evaledSrcScriptNum++

if (window.evaledSrcScriptNum === 2)
  window.evaledScriptLoaded()
