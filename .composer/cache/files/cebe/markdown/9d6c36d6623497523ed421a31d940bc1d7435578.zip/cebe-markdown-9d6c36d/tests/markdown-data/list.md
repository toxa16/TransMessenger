- item1
- 
- item2
- item3

---

* item1
* item2
* item3

---

+ item1
+ item2
+ item3

---

1. item1
2. item2
4. item3

---

4.   item1
12.  item2
125. item3

---

4. item1
12. item2
125. item3

---

  4. item1
 12. item2
125. item3

---

-   more indented line
- different indent
-not a list item
