this is __strong__ and this is **strong**.

this is _em_ and this is *em*.

_`code`_ __`code`__

*`code`**`code`**`code`*

Hey *this is
italic*

Hey **this is
bold**
