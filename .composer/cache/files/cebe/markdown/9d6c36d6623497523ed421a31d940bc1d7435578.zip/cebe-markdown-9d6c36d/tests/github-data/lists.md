Text before list:
 * item 1,
 * item 2,
 * item 3.

Text after list.